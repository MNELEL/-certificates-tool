// ניהול מפתח Anthropic API אישי - כל משתמש מזין את המפתח שלו בעצמו, ונשמר
// אך ורק בדפדפן שלו (localStorage), ולא בקוד/build המשותף.
// זה מחליף את הגישה הקודמת (VITE_ANTHROPIC_API_KEY גלובלי בזמן build).

const STORAGE_KEY = "certificates-tool:anthropic-api-key";

export function getPersonalApiKey(): string | null {
  try {
    return localStorage.getItem(STORAGE_KEY);
  } catch {
    return null;
  }
}

export function setPersonalApiKey(key: string): void {
  localStorage.setItem(STORAGE_KEY, key.trim());
}

export function clearPersonalApiKey(): void {
  localStorage.removeItem(STORAGE_KEY);
}

/**
 * מחזיר את המפתח לשימוש: קודם כל מפתח אישי שהוזן ע"י המשתמש בדפדפן שלו,
 * ורק אם אין כזה - נופל חזרה למפתח הגלובלי מה-build (אם קיים, לתאימות לאחור).
 */
export function resolveApiKey(): string | null {
  const personal = getPersonalApiKey();
  if (personal) return personal;
  const envKey = import.meta.env.VITE_ANTHROPIC_API_KEY as string | undefined;
  return envKey || null;
}
