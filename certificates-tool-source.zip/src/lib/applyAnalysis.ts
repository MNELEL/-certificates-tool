// לוגיקה משותפת: לוקחת תוצאת ניתוח AI (ראה aiAnalysis.ts) ומעדכנת את הטבלאות
// הרלוונטיות ב-Supabase - ציונים, מבחנים/מועדי בחינות, הערות התנהגות, ונושאים.
// משמשת גם את MaterialsTab (ניתוח לכיתה ספציפית) וגם את ה-Smart Ingest הגלובלי.

import { supabase } from "./supabase";
import type { AiAnalysisResult } from "./aiAnalysis";
import type { Student, Subject } from "../types";

export interface ApplySummary {
  gradesCreated: number;
  behaviorNotesCreated: number;
  examDatesCreated: number;
  topicsCreated: number;
  matchedSubjectName: string | null;
  unmatchedStudentNames: string[];
}

function matchSubject(subjects: Subject[], guess: string | null): Subject | undefined {
  if (!guess) return undefined;
  return subjects.find((s) => s.name.includes(guess) || guess.includes(s.name));
}

function matchStudent(students: Student[], name: string | null): Student | undefined {
  if (!name) return undefined;
  return students.find((s) => s.full_name.includes(name) || name.includes(s.full_name));
}

export async function applyAiAnalysisResult(params: {
  classId: string;
  subjects: Subject[];
  students: Student[];
  result: AiAnalysisResult;
  materialId: string | null;
}): Promise<ApplySummary> {
  const { classId, subjects, students, result, materialId } = params;
  const summary: ApplySummary = {
    gradesCreated: 0,
    behaviorNotesCreated: 0,
    examDatesCreated: 0,
    topicsCreated: 0,
    matchedSubjectName: null,
    unmatchedStudentNames: [],
  };

  const matchedSubject = matchSubject(subjects, result.detected_subject_guess);
  summary.matchedSubjectName = matchedSubject?.name ?? null;

  // 1. ציונים - יוצרים מבחן (אם יש מקצוע מתאים) ומשייכים ציונים מוצעים
  if (result.grades.length > 0 && matchedSubject) {
    const { data: examData, error: examErr } = await supabase
      .from("exams")
      .insert({
        class_id: classId,
        subject_id: matchedSubject.id,
        material_id: materialId,
        title: result.summary.slice(0, 80) || "מבחן",
        exam_date: result.detected_date,
        period: "a",
      })
      .select()
      .single();

    if (!examErr && examData) {
      for (const g of result.grades) {
        const matchedStudent = matchStudent(students, g.student_name);
        if (matchedStudent && g.score !== null) {
          const { error } = await supabase.from("grades").insert({
            exam_id: examData.id,
            student_id: matchedStudent.id,
            ai_suggested_score: g.score,
            status: "pending",
            source_material_id: materialId,
          });
          if (!error) summary.gradesCreated += 1;
        } else if (!matchedStudent) {
          summary.unmatchedStudentNames.push(g.student_name);
        }
      }
    }
  }

  // 2. מועדי בחינות עתידיים (ללא ציונים עדיין) - נרשמים כ"מבחן מתוכנן"
  for (const ed of result.exam_dates) {
    const subj = matchSubject(subjects, ed.subject_guess) ?? matchedSubject;
    if (!subj) continue;
    const { error } = await supabase.from("exams").insert({
      class_id: classId,
      subject_id: subj.id,
      material_id: materialId,
      title: ed.title || "מועד בחינה",
      exam_date: ed.exam_date,
      period: "a",
      is_scheduled_only: true,
    });
    if (!error) summary.examDatesCreated += 1;
  }

  // 3. הערות התנהגות
  for (const bn of result.behavior_notes) {
    const matchedStudent = matchStudent(students, bn.student_name);
    if (bn.student_name && !matchedStudent) {
      summary.unmatchedStudentNames.push(bn.student_name);
    }
    const { error } = await supabase.from("behavior_notes").insert({
      class_id: classId,
      student_id: matchedStudent?.id ?? null,
      note: bn.note,
      note_type: bn.note_type,
      note_date: result.detected_date,
      source_material_id: materialId,
    });
    if (!error) summary.behaviorNotesCreated += 1;
  }

  // 4. נושאים שנלמדו
  for (const t of result.topics) {
    const subj = matchSubject(subjects, t.subject_guess) ?? matchedSubject;
    const { error } = await supabase.from("topics").insert({
      class_id: classId,
      subject_id: subj?.id ?? null,
      name: t.name,
      topic_date: result.detected_date,
      source_material_id: materialId,
    });
    if (!error) summary.topicsCreated += 1;
  }

  return summary;
}
