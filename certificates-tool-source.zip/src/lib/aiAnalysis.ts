// מודול זה שולח את תוכן הקובץ (תמונה/PDF) למודל Claude ומבקש ניתוח מובנה ומקיף:
// סוג מסמך, מקצוע, תאריך, ציונים, הערות התנהגות, מועדי בחינות, ונושאים שנלמדו.
// המפתח נלקח מהמפתח האישי שהמשתמש הזין בדפדפן שלו (src/lib/apiKey.ts).

import { resolveApiKey } from "./apiKey";

export interface AiDetectedGrade {
  student_name: string;
  score: number | null;
  confidence: "high" | "medium" | "low";
}

export interface AiDetectedBehaviorNote {
  student_name: string | null; // null אם ההערה כללית ולא לתלמיד ספציפי
  note: string;
  note_type: "general" | "positive" | "concern";
}

export interface AiDetectedExamDate {
  title: string;
  exam_date: string | null; // YYYY-MM-DD
  subject_guess: string | null;
}

export interface AiDetectedTopic {
  name: string;
  subject_guess: string | null;
}

export interface AiAnalysisResult {
  detected_type: "test" | "worksheet" | "material" | "behavior_log" | "schedule" | "other";
  detected_subject_guess: string | null;
  detected_date: string | null; // ISO date אם זוהה
  summary: string;
  grades: AiDetectedGrade[];
  behavior_notes: AiDetectedBehaviorNote[];
  exam_dates: AiDetectedExamDate[];
  topics: AiDetectedTopic[];
}

const SYSTEM_PROMPT = `אתה עוזר למורה בבית ספר תורני (חדר/ישיבה קטנה) לנתח כל תמונה או מסמך שהועלה -
מבחן, דף עבודה, חומר לימוד, יומן/דו"ח התנהגות, לוח מועדי בחינות, או כל פתק אחר.
המשימה שלך היא לזהות מה יש במסמך ולחלץ ממנו נתונים מובנים, כדי שהמערכת תוכל לעדכן
אוטומטית את הטבלאות המתאימות: ציונים, התנהגות, מבחנים ומועדי בחינות, חומרים ונושאים.

החזר אך ורק JSON תקני (ללא markdown, ללא טקסט נוסף) בפורמט המדויק הבא:
{
  "detected_type": "test" | "worksheet" | "material" | "behavior_log" | "schedule" | "other",
  "detected_subject_guess": string | null,
  "detected_date": "YYYY-MM-DD" | null,
  "summary": string (משפט אחד בעברית שמתאר את המסמך),
  "grades": [ { "student_name": string, "score": number | null, "confidence": "high"|"medium"|"low" } ],
  "behavior_notes": [ { "student_name": string | null, "note": string, "note_type": "general"|"positive"|"concern" } ],
  "exam_dates": [ { "title": string, "exam_date": "YYYY-MM-DD" | null, "subject_guess": string | null } ],
  "topics": [ { "name": string, "subject_guess": string | null } ]
}

הנחיות:
- אם יש טבלת ציונים (שם+ציון) או ציון בודד בכתב יד - חלץ ל-grades.
- אם המסמך מתעד התנהגות תלמיד (חיובית או בעייתית), חלץ הערה קצרה ל-behavior_notes.
  שים student_name=null רק אם ההערה כללית לכל הכיתה ולא לתלמיד מסוים.
- אם מופיע תאריך/מועד בחינה עתידי (גם אם עדיין אין ציונים), חלץ ל-exam_dates.
- אם מזוהים נושאי לימוד שנלמדו/יילמדו (למשל "פרק ג משנה תרומות", "דף כט עמוד ב"), חלץ ל-topics.
- אל תמציא נתונים שאינך רואה בבירור במסמך. מערך ריק [] אם הקטגוריה לא רלוונטית למסמך.
- כתוב בעברית בכל שדה טקסט חופשי (note, title, name, summary).`;

export async function analyzeDocument(params: {
  base64Data: string;
  mediaType: string; // image/jpeg, image/png, application/pdf
}): Promise<AiAnalysisResult> {
  const apiKey = resolveApiKey();
  if (!apiKey) {
    throw new Error(
      "לא הוגדר מפתח Anthropic אישי. לחץ על 'הגדרות AI' למעלה והזן את המפתח שלך (נשמר רק בדפדפן שלך)."
    );
  }

  const contentBlock =
    params.mediaType === "application/pdf"
      ? { type: "document", source: { type: "base64", media_type: params.mediaType, data: params.base64Data } }
      : { type: "image", source: { type: "base64", media_type: params.mediaType, data: params.base64Data } };

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 2000,
      system: SYSTEM_PROMPT,
      messages: [
        {
          role: "user",
          content: [contentBlock, { type: "text", text: "נתח את המסמך המצורף לפי ההוראות." }],
        },
      ],
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    if (response.status === 401) {
      throw new Error("המפתח שהוזן לא תקין או פג תוקף. בדוק ב'הגדרות AI' שהמפתח נכון.");
    }
    throw new Error(`שגיאה בקריאה ל-API: ${response.status} ${errText}`);
  }

  const data = await response.json();
  const textBlock = data.content?.find((b: { type: string }) => b.type === "text");
  if (!textBlock) throw new Error("לא התקבלה תשובת טקסט מהמודל.");

  const cleaned = textBlock.text.replace(/```json|```/g, "").trim();
  try {
    const parsed = JSON.parse(cleaned) as Partial<AiAnalysisResult>;
    // ברירות מחדל למקרה שהמודל השמיט קטגוריה
    return {
      detected_type: parsed.detected_type ?? "other",
      detected_subject_guess: parsed.detected_subject_guess ?? null,
      detected_date: parsed.detected_date ?? null,
      summary: parsed.summary ?? "",
      grades: parsed.grades ?? [],
      behavior_notes: parsed.behavior_notes ?? [],
      exam_dates: parsed.exam_dates ?? [],
      topics: parsed.topics ?? [],
    };
  } catch {
    throw new Error("לא ניתן היה לפענח את תשובת ה-AI כ-JSON תקין.");
  }
}

export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      resolve(result.split(",")[1]);
    };
    reader.onerror = () => reject(new Error("קריאת הקובץ נכשלה"));
    reader.readAsDataURL(file);
  });
}
