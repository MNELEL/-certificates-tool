import { useEffect, useRef, useState } from "react";
import { supabase } from "../lib/supabase";
import { analyzeDocument, fileToBase64, type AiAnalysisResult } from "../lib/aiAnalysis";
import { applyAiAnalysisResult, type ApplySummary } from "../lib/applyAnalysis";
import { getPersonalApiKey } from "../lib/apiKey";
import AiSettingsModal from "./AiSettingsModal";
import type { ClassRow, Student, Subject } from "../types";

type Stage = "idle" | "picking-class" | "analyzing" | "preview" | "applying" | "done" | "error";

const typeLabels: Record<string, string> = {
  test: "מבחן עם ציונים",
  worksheet: "דף עבודה",
  material: "חומר לימוד",
  behavior_log: "דו״ח התנהגות",
  schedule: "לוח מועדים",
  other: "מסמך כללי",
};

export default function AiIngestDock() {
  const [open, setOpen] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [stage, setStage] = useState<Stage>("idle");
  const [classes, setClasses] = useState<ClassRow[]>([]);
  const [selectedClassId, setSelectedClassId] = useState<string>("");
  const [file, setFile] = useState<File | null>(null);
  const [result, setResult] = useState<AiAnalysisResult | null>(null);
  const [summary, setSummary] = useState<ApplySummary | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open && classes.length === 0) {
      supabase
        .from("classes")
        .select("*")
        .order("created_at", { ascending: false })
        .then(({ data }) => data && setClasses(data as ClassRow[]));
    }
  }, [open, classes.length]);

  function reset() {
    setStage("idle");
    setFile(null);
    setResult(null);
    setSummary(null);
    setError(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  }

  function handleClose() {
    setOpen(false);
    reset();
  }

  async function handleFilePicked(f: File | null) {
    if (!f) return;
    if (!getPersonalApiKey() && !import.meta.env.VITE_ANTHROPIC_API_KEY) {
      setShowSettings(true);
      return;
    }
    setFile(f);
    if (!selectedClassId) {
      setStage("picking-class");
      return;
    }
    await runAnalysis(f, selectedClassId);
  }

  async function runAnalysis(f: File, classId: string) {
    setStage("analyzing");
    setError(null);
    try {
      const base64 = await fileToBase64(f);
      const mediaType = f.type || "image/jpeg";
      const analysis = await analyzeDocument({ base64Data: base64, mediaType });
      setResult(analysis);
      setStage("preview");
      void classId;
    } catch (err) {
      setError(err instanceof Error ? err.message : "שגיאה בניתוח");
      setStage("error");
    }
  }

  async function handleConfirmApply() {
    if (!result || !selectedClassId || !file) return;
    setStage("applying");
    setError(null);
    try {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) throw new Error("לא מחובר");

      // שומרים את הקובץ עצמו כ"חומר" לצורך תיעוד/מעקב, בדיוק כמו העלאה רגילה
      const path = `${userData.user.id}/${selectedClassId}/${Date.now()}_${file.name}`;
      await supabase.storage.from("materials").upload(path, file);
      const { data: materialRow } = await supabase
        .from("materials")
        .insert({
          class_id: selectedClassId,
          file_path: path,
          file_name: file.name,
          file_type: file.type,
          ai_detected_type: result.detected_type,
          ai_detected_date: result.detected_date,
          ai_summary: result.summary,
          status: "processed",
        })
        .select()
        .single();

      const [{ data: subjects }, { data: students }] = await Promise.all([
        supabase.from("subjects").select("*").eq("class_id", selectedClassId),
        supabase.from("students").select("*").eq("class_id", selectedClassId),
      ]);

      const applySummary = await applyAiAnalysisResult({
        classId: selectedClassId,
        subjects: (subjects as Subject[]) ?? [],
        students: (students as Student[]) ?? [],
        result,
        materialId: materialRow?.id ?? null,
      });

      setSummary(applySummary);
      setStage("done");
    } catch (err) {
      setError(err instanceof Error ? err.message : "שגיאה בעדכון הנתונים");
      setStage("error");
    }
  }

  return (
    <>
      {/* כפתור צף - זמין בכל מסך באפליקציה */}
      <button
        onClick={() => setOpen(true)}
        className="fixed bottom-5 left-5 z-40 bg-stone-800 text-white rounded-full w-14 h-14 shadow-lg hover:bg-stone-700 flex items-center justify-center text-2xl"
        title="ניתוח AI מהיר - העלה כל תמונה"
      >
        🤖
      </button>

      {open && (
        <div className="fixed inset-0 bg-black/40 flex items-end sm:items-center justify-center z-50 p-4" onClick={handleClose}>
          <div
            className="bg-white rounded-xl p-5 max-w-md w-full shadow-xl max-h-[85vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center mb-3">
              <h3 className="font-semibold text-stone-800">ניתוח AI מהיר</h3>
              <div className="flex gap-3 items-center">
                <button
                  onClick={() => setShowSettings(true)}
                  className="text-xs text-stone-400 hover:text-stone-600 hover:underline"
                >
                  הגדרות AI
                </button>
                <button onClick={handleClose} className="text-stone-400 hover:text-stone-600 text-lg leading-none">
                  ×
                </button>
              </div>
            </div>

            <p className="text-sm text-stone-500 mb-4">
              העלה כל תמונה - מבחן, דף ציונים, דו״ח התנהגות, לוח מועדי בחינות או חומר לימוד -
              והמערכת תזהה בעצמה מה זה ותעדכן את הכיתה המתאימה.
            </p>

            {/* שלב 1: בחירת כיתה (תמיד נדרש כדי לדעת לאן לשייך את הנתונים) */}
            <label className="text-xs text-stone-500 block mb-1">כיתה</label>
            <select
              value={selectedClassId}
              onChange={(e) => setSelectedClassId(e.target.value)}
              className="w-full rounded-lg border border-stone-300 px-3 py-2 text-sm mb-3"
            >
              <option value="">בחר כיתה...</option>
              {classes.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>

            {stage === "idle" || stage === "picking-class" ? (
              <>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*,application/pdf"
                  onChange={(e) => handleFilePicked(e.target.files?.[0] ?? null)}
                  className="text-sm mb-2"
                />
                {stage === "picking-class" && !selectedClassId && (
                  <p className="text-xs text-amber-600">בחר כיתה קודם, ואז נריץ את הניתוח.</p>
                )}
                {stage === "picking-class" && selectedClassId && file && (
                  <button
                    onClick={() => runAnalysis(file, selectedClassId)}
                    className="bg-stone-800 text-white rounded-lg px-3 py-1.5 text-sm mt-2"
                  >
                    נתח עכשיו
                  </button>
                )}
              </>
            ) : null}

            {stage === "analyzing" && <p className="text-sm text-stone-500">מנתח את המסמך...</p>}

            {stage === "preview" && result && (
              <div className="space-y-3">
                <div className="bg-stone-50 rounded-lg p-3 text-sm">
                  <p className="font-medium text-stone-800">
                    {typeLabels[result.detected_type] ?? result.detected_type}
                  </p>
                  {result.summary && <p className="text-stone-600 mt-1">{result.summary}</p>}
                  <div className="flex flex-wrap gap-2 mt-2 text-xs text-stone-500">
                    {result.detected_subject_guess && <span>מקצוע: {result.detected_subject_guess}</span>}
                    {result.detected_date && <span>תאריך: {result.detected_date}</span>}
                  </div>
                </div>

                {result.grades.length > 0 && (
                  <p className="text-sm text-stone-700">📊 {result.grades.length} ציונים זוהו</p>
                )}
                {result.behavior_notes.length > 0 && (
                  <p className="text-sm text-stone-700">📝 {result.behavior_notes.length} הערות התנהגות זוהו</p>
                )}
                {result.exam_dates.length > 0 && (
                  <p className="text-sm text-stone-700">📅 {result.exam_dates.length} מועדי בחינה זוהו</p>
                )}
                {result.topics.length > 0 && (
                  <p className="text-sm text-stone-700">📚 {result.topics.length} נושאים זוהו</p>
                )}
                {result.grades.length === 0 &&
                  result.behavior_notes.length === 0 &&
                  result.exam_dates.length === 0 &&
                  result.topics.length === 0 && (
                    <p className="text-sm text-stone-400">לא זוהו נתונים מובנים - יישמר רק כחומר לימוד.</p>
                  )}

                <div className="flex gap-2 justify-end pt-2">
                  <button onClick={reset} className="text-sm text-stone-500 hover:underline px-2">
                    ביטול
                  </button>
                  <button
                    onClick={handleConfirmApply}
                    className="bg-stone-800 text-white rounded-lg px-4 py-1.5 text-sm hover:bg-stone-700"
                  >
                    אשר ועדכן
                  </button>
                </div>
              </div>
            )}

            {stage === "applying" && <p className="text-sm text-stone-500">מעדכן את הכיתה...</p>}

            {stage === "done" && summary && (
              <div className="space-y-2">
                <p className="text-sm text-green-700 font-medium">עודכן בהצלחה ✓</p>
                <ul className="text-sm text-stone-600 list-disc pr-5">
                  {summary.gradesCreated > 0 && <li>{summary.gradesCreated} ציונים נוספו</li>}
                  {summary.behaviorNotesCreated > 0 && <li>{summary.behaviorNotesCreated} הערות התנהגות נוספו</li>}
                  {summary.examDatesCreated > 0 && <li>{summary.examDatesCreated} מועדי בחינה נוספו</li>}
                  {summary.topicsCreated > 0 && <li>{summary.topicsCreated} נושאים נוספו</li>}
                </ul>
                {summary.unmatchedStudentNames.length > 0 && (
                  <p className="text-xs text-amber-600">
                    שמות שלא הותאמו לתלמיד קיים: {summary.unmatchedStudentNames.join(", ")}
                  </p>
                )}
                <button
                  onClick={reset}
                  className="bg-stone-800 text-white rounded-lg px-4 py-1.5 text-sm hover:bg-stone-700 mt-2"
                >
                  ניתוח נוסף
                </button>
              </div>
            )}

            {stage === "error" && error && (
              <div className="space-y-2">
                <p className="text-sm text-red-600">{error}</p>
                <button onClick={reset} className="text-sm text-stone-500 hover:underline">
                  נסה שוב
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {showSettings && <AiSettingsModal onClose={() => setShowSettings(false)} />}
    </>
  );
}
