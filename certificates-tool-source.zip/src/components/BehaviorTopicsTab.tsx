import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";
import type { BehaviorNote, Student, Subject, Topic } from "../types";

const noteTypeLabels: Record<string, string> = {
  general: "כללי",
  positive: "חיובי",
  concern: "לתשומת לב",
};

const noteTypeColors: Record<string, string> = {
  general: "bg-stone-100 text-stone-600",
  positive: "bg-green-100 text-green-700",
  concern: "bg-amber-100 text-amber-700",
};

export default function BehaviorTopicsTab({ classId }: { classId: string }) {
  const [notes, setNotes] = useState<BehaviorNote[]>([]);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);

  const [newNote, setNewNote] = useState("");
  const [newNoteStudent, setNewNoteStudent] = useState("");
  const [newNoteType, setNewNoteType] = useState<"general" | "positive" | "concern">("general");

  const [newTopic, setNewTopic] = useState("");
  const [newTopicSubject, setNewTopicSubject] = useState("");

  async function load() {
    const [{ data: n }, { data: t }, { data: st }, { data: su }] = await Promise.all([
      supabase.from("behavior_notes").select("*").eq("class_id", classId).order("created_at", { ascending: false }),
      supabase.from("topics").select("*").eq("class_id", classId).order("created_at", { ascending: false }),
      supabase.from("students").select("*").eq("class_id", classId).order("full_name"),
      supabase.from("subjects").select("*").eq("class_id", classId).order("name"),
    ]);
    if (n) setNotes(n as BehaviorNote[]);
    if (t) setTopics(t as Topic[]);
    if (st) setStudents(st as Student[]);
    if (su) setSubjects(su as Subject[]);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [classId]);

  async function addNote(e: React.FormEvent) {
    e.preventDefault();
    if (!newNote.trim()) return;
    await supabase.from("behavior_notes").insert({
      class_id: classId,
      student_id: newNoteStudent || null,
      note: newNote.trim(),
      note_type: newNoteType,
    });
    setNewNote("");
    load();
  }

  async function addTopic(e: React.FormEvent) {
    e.preventDefault();
    if (!newTopic.trim()) return;
    await supabase.from("topics").insert({
      class_id: classId,
      subject_id: newTopicSubject || null,
      name: newTopic.trim(),
    });
    setNewTopic("");
    load();
  }

  async function removeNote(id: string) {
    await supabase.from("behavior_notes").delete().eq("id", id);
    load();
  }

  async function removeTopic(id: string) {
    await supabase.from("topics").delete().eq("id", id);
    load();
  }

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <section>
        <div className="bg-white border border-stone-200 rounded-xl p-4 mb-4">
          <h3 className="font-semibold text-stone-800 mb-3">הערת התנהגות חדשה</h3>
          <form onSubmit={addNote} className="space-y-2">
            <textarea
              value={newNote}
              onChange={(e) => setNewNote(e.target.value)}
              placeholder="תוכן ההערה"
              rows={2}
              className="w-full rounded-lg border border-stone-300 px-3 py-1.5 text-sm"
            />
            <div className="flex gap-2 flex-wrap">
              <select
                value={newNoteStudent}
                onChange={(e) => setNewNoteStudent(e.target.value)}
                className="rounded-lg border border-stone-300 px-2 py-1.5 text-sm flex-1"
              >
                <option value="">כללי (לא לתלמיד ספציפי)</option>
                {students.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.full_name}
                  </option>
                ))}
              </select>
              <select
                value={newNoteType}
                onChange={(e) => setNewNoteType(e.target.value as typeof newNoteType)}
                className="rounded-lg border border-stone-300 px-2 py-1.5 text-sm"
              >
                <option value="general">כללי</option>
                <option value="positive">חיובי</option>
                <option value="concern">לתשומת לב</option>
              </select>
              <button className="bg-stone-800 text-white rounded-lg px-3 py-1.5 text-sm">הוסף</button>
            </div>
          </form>
        </div>

        <div className="space-y-2">
          {notes.map((n) => (
            <div key={n.id} className="bg-white border border-stone-200 rounded-xl p-3">
              <div className="flex justify-between items-start gap-2">
                <div>
                  <p className="text-sm text-stone-700">{n.note}</p>
                  <div className="flex gap-2 mt-1 items-center flex-wrap">
                    <span className={`text-xs rounded-full px-2 py-0.5 ${noteTypeColors[n.note_type]}`}>
                      {noteTypeLabels[n.note_type]}
                    </span>
                    <span className="text-xs text-stone-400">
                      {students.find((s) => s.id === n.student_id)?.full_name ?? "כללי"}
                    </span>
                    {n.note_date && <span className="text-xs text-stone-400">{n.note_date}</span>}
                  </div>
                </div>
                <button onClick={() => removeNote(n.id)} className="text-stone-400 hover:text-red-500 text-xs">
                  הסר
                </button>
              </div>
            </div>
          ))}
          {notes.length === 0 && <p className="text-stone-400 text-sm">אין עדיין הערות התנהגות.</p>}
        </div>
      </section>

      <section>
        <div className="bg-white border border-stone-200 rounded-xl p-4 mb-4">
          <h3 className="font-semibold text-stone-800 mb-3">נושא חדש</h3>
          <form onSubmit={addTopic} className="space-y-2">
            <input
              value={newTopic}
              onChange={(e) => setNewTopic(e.target.value)}
              placeholder="שם הנושא (למשל: משנה תרומות פרק ג)"
              className="w-full rounded-lg border border-stone-300 px-3 py-1.5 text-sm"
            />
            <div className="flex gap-2">
              <select
                value={newTopicSubject}
                onChange={(e) => setNewTopicSubject(e.target.value)}
                className="rounded-lg border border-stone-300 px-2 py-1.5 text-sm flex-1"
              >
                <option value="">ללא מקצוע</option>
                {subjects.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
              <button className="bg-stone-800 text-white rounded-lg px-3 py-1.5 text-sm">הוסף</button>
            </div>
          </form>
        </div>

        <div className="space-y-2">
          {topics.map((t) => (
            <div key={t.id} className="bg-white border border-stone-200 rounded-xl p-3 flex justify-between items-center">
              <div>
                <p className="text-sm text-stone-700">{t.name}</p>
                <div className="flex gap-2 mt-1">
                  {t.subject_id && (
                    <span className="text-xs text-stone-400">
                      {subjects.find((s) => s.id === t.subject_id)?.name}
                    </span>
                  )}
                  {t.topic_date && <span className="text-xs text-stone-400">{t.topic_date}</span>}
                </div>
              </div>
              <button onClick={() => removeTopic(t.id)} className="text-stone-400 hover:text-red-500 text-xs">
                הסר
              </button>
            </div>
          ))}
          {topics.length === 0 && <p className="text-stone-400 text-sm">אין עדיין נושאים.</p>}
        </div>
      </section>
    </div>
  );
}
