import { useState } from "react";
import { getPersonalApiKey, setPersonalApiKey, clearPersonalApiKey } from "../lib/apiKey";

export default function AiSettingsModal({ onClose }: { onClose: () => void }) {
  const [key, setKey] = useState(getPersonalApiKey() ?? "");
  const [saved, setSaved] = useState(false);

  function handleSave() {
    if (!key.trim()) return;
    setPersonalApiKey(key.trim());
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  }

  function handleClear() {
    clearPersonalApiKey();
    setKey("");
  }

  return (
    <div
      className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-xl p-5 max-w-md w-full shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <h3 className="font-semibold text-stone-800 mb-1">הגדרות AI - מפתח אישי</h3>
        <p className="text-sm text-stone-500 mb-4">
          כל משתמש מזין כאן את מפתח ה-Anthropic API האישי שלו. המפתח נשמר{" "}
          <span className="font-medium">רק בדפדפן שלך</span> (localStorage) ואינו נשלח לשום שרת
          חוץ מ-Anthropic עצמה בזמן ניתוח. אפשר ליצור מפתח בכתובת{" "}
          <a
            href="https://console.anthropic.com/settings/keys"
            target="_blank"
            rel="noreferrer"
            className="underline"
          >
            console.anthropic.com
          </a>
          .
        </p>

        <input
          type="password"
          value={key}
          onChange={(e) => setKey(e.target.value)}
          placeholder="sk-ant-..."
          dir="ltr"
          className="w-full rounded-lg border border-stone-300 px-3 py-2 text-sm mb-3 font-mono"
        />

        <div className="flex gap-2 justify-end">
          {getPersonalApiKey() && (
            <button
              onClick={handleClear}
              className="text-sm text-red-600 hover:underline px-2"
            >
              מחק מפתח
            </button>
          )}
          <button
            onClick={onClose}
            className="text-sm text-stone-500 hover:underline px-2"
          >
            סגור
          </button>
          <button
            onClick={handleSave}
            className="bg-stone-800 text-white rounded-lg px-4 py-1.5 text-sm hover:bg-stone-700"
          >
            {saved ? "נשמר ✓" : "שמור"}
          </button>
        </div>
      </div>
    </div>
  );
}
